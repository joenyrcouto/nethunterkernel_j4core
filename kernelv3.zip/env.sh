#!/sbin/sh
export LIBDIR=/system/lib
export ARCH=armhf
